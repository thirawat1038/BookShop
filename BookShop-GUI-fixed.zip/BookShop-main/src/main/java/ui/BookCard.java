package ui;

import model.Product;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * การ์ดหนังสือ 1 เล่ม: ปก / ชื่อ / คงเหลือ / หมวด / ราคา / ปุ่มตะกร้า (วงกลมสีฟ้า)
 * ถ้าสินค้าไม่มีรูป (imagePath ว่างหรือหาไฟล์ไม่เจอ) จะสร้างปกสีไล่เฉดจากชื่อหนังสือให้อัตโนมัติ
 */
final class BookCard extends JPanel {

    static final int CARD_W = 130;
    static final int COVER_H = 182;

    BookCard(Product product, Consumer<Product> onAddToCart, Consumer<Product> onOpen) {
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        Cover cover = new Cover(product, CARD_W, COVER_H);
        cover.setAlignmentX(LEFT_ALIGNMENT);
        add(cover);
        add(Box.createVerticalStrut(8));

        TextBlock nameBlock = new TextBlock(product.getName(), Theme.font(Font.PLAIN, 13f), Theme.TEXT, CARD_W, 2);
        add(nameBlock);
        add(new TextBlock(product.getStock() > 0 ? "คงเหลือ " + product.getStock() + " เล่ม" : "สินค้าหมด",
                Theme.font(Font.PLAIN, 12f), product.getStock() > 0 ? Theme.MUTED : new Color(0xD64545), CARD_W, 1));
        add(new TextBlock("Books", Theme.font(Font.PLAIN, 12f), Theme.MUTED, CARD_W, 1));
        add(Box.createVerticalStrut(2));

        JPanel priceRow = new JPanel(new BorderLayout());
        priceRow.setOpaque(false);
        priceRow.setAlignmentX(LEFT_ALIGNMENT);
        priceRow.setMaximumSize(new Dimension(CARD_W, 38));
        priceRow.setPreferredSize(new Dimension(CARD_W, 38));

        JLabel price = new JLabel(String.format(Locale.US, "%,.2f บาท", product.getPrice()));
        price.setFont(Theme.font(Font.BOLD, 14f));
        price.setForeground(Theme.TEXT);
        priceRow.add(price, BorderLayout.WEST);

        CartButton cartButton = new CartButton(product.getStock() > 0);
        cartButton.setToolTipText(product.getStock() > 0 ? "เพิ่มลงตะกร้า" : "สินค้าหมด");
        cartButton.addActionListener(e -> onAddToCart.accept(product));
        priceRow.add(cartButton, BorderLayout.EAST);
        add(priceRow);

        // คลิกที่ปกหรือชื่อหนังสือ -> เปิดหน้ารายละเอียด
        for (JComponent c : new JComponent[]{cover, nameBlock}) {
            onClick(c, () -> onOpen.accept(product));
            c.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
    }

    /**
     * ทำงานเมื่อ "ปล่อยเมาส์" ภายในคอมโพเนนต์ (เหมือนปุ่มจริง)
     * ไม่ใช้ mouseClicked เพราะ Swing จะไม่ยิง event ถ้าเมาส์ขยับแม้ 1 พิกเซลระหว่างกด-ปล่อย ทำให้ "กดไม่ค่อยติด"
     */
    static void onClick(JComponent c, Runnable action) {
        c.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e) && c.contains(e.getPoint())) {
                    action.run();
                }
            }
        });
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return new Dimension(CARD_W, d.height);
    }

    @Override
    public Dimension getMaximumSize() {
        return getPreferredSize();
    }

    // ------------------------------------------------------------------
    // ปกหนังสือ
    // ------------------------------------------------------------------
    static final class Cover extends JComponent {
        private final Product product;
        private final int coverW;
        private final int coverH;
        private BufferedImage image;

        Cover(Product product, int coverW, int coverH) {
            this.product = product;
            this.coverW = coverW;
            this.coverH = coverH;
            setOpaque(false);
            String path = product.getImagePath();
            if (path != null && !path.isBlank()) {
                File file = new File(path);
                if (file.isFile()) {
                    try {
                        image = ImageIO.read(file);
                    } catch (Exception ignored) {
                        image = null;
                    }
                }
            }
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(coverW, coverH);
        }

        @Override
        public Dimension getMaximumSize() {
            return getPreferredSize();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            Theme.antialias(g2);
            int w = getWidth();
            int h = getHeight();
            Shape shape = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 10, 10);
            g2.setClip(shape);

            if (image != null) {
                // ครอบรูปให้เต็มกรอบ (cover) โดยตัดส่วนเกินตรงกลาง
                double scale = Math.max((double) w / image.getWidth(), (double) h / image.getHeight());
                int dw = (int) Math.round(image.getWidth() * scale);
                int dh = (int) Math.round(image.getHeight() * scale);
                g2.drawImage(image, (w - dw) / 2, (h - dh) / 2, dw, dh, null);
            } else {
                paintGenerated(g2, w, h);
            }

            g2.setClip(null);
            g2.setColor(new Color(0, 0, 0, 40));
            g2.draw(shape);
            g2.dispose();
        }

        private void paintGenerated(Graphics2D g2, int w, int h) {
            // ใช้อัตราส่วนทองคำกระจายสี เพราะ id อย่าง b01, b02 มี hash ใกล้กันมาก
            double frac = (product.getId().hashCode() * 0.6180339887) % 1.0;
            float hue = (float) (frac < 0 ? frac + 1.0 : frac);
            Color top = Color.getHSBColor(hue, 0.55f, 0.42f);
            Color bottom = Color.getHSBColor((hue + 0.08f) % 1f, 0.65f, 0.80f);
            g2.setPaint(new GradientPaint(0, 0, top, w, h, bottom));
            g2.fillRect(0, 0, w, h);

            // ลายตกแต่งเล็กน้อยให้ไม่ดูโล่ง
            g2.setColor(new Color(255, 255, 255, 38));
            g2.fill(new Ellipse2D.Float(w * 0.35f, -h * 0.15f, w * 0.9f, w * 0.9f));
            g2.setColor(new Color(255, 255, 255, 60));
            g2.fillRect(0, h - 34, w, 2);

            g2.setColor(Color.WHITE);
            TextBlock.drawLines(g2, product.getName(), Theme.font(Font.BOLD, 15f), 12, 28, w - 24, 5, true);
        }
    }

    // ------------------------------------------------------------------
    // ปุ่มตะกร้าวงกลม (วาดไอคอนเอง ไม่พึ่งฟอนต์ emoji)
    // ------------------------------------------------------------------
    static final class CartButton extends JButton {
        private final boolean enabledLook;

        CartButton(boolean available) {
            this.enabledLook = available;
            setEnabled(available);
            setPreferredSize(new Dimension(36, 36));
            setMinimumSize(new Dimension(36, 36));
            setMaximumSize(new Dimension(36, 36));
            setBorderPainted(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setCursor(Cursor.getPredefinedCursor(available ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            Theme.antialias(g2);
            int size = Math.min(getWidth(), getHeight()) - 2;
            g2.translate((getWidth() - size) / 2.0, (getHeight() - size) / 2.0);

            Color fill = !enabledLook ? new Color(0xC9C9C9)
                    : getModel().isPressed() ? Theme.BLUE_DARK
                    : getModel().isRollover() ? new Color(0x4FB8F5) : Theme.BLUE;
            g2.setColor(fill);
            g2.fill(new Ellipse2D.Float(0, 0, size, size));

            // ไอคอนรถเข็น
            double s = size / 28.0;
            g2.scale(s, s);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            Path2D cart = new Path2D.Float();
            cart.moveTo(6, 8);
            cart.lineTo(9, 8);
            cart.lineTo(11.2, 17.5);
            cart.lineTo(19.8, 17.5);
            cart.lineTo(21.8, 11);
            cart.lineTo(9.6, 11);
            g2.draw(cart);
            g2.fill(new Ellipse2D.Float(10.6f, 19.6f, 3.2f, 3.2f));
            g2.fill(new Ellipse2D.Float(17.4f, 19.6f, 3.2f, 3.2f));
            g2.dispose();
        }
    }
}
